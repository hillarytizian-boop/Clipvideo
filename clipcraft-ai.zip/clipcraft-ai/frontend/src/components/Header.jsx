export default function Header({ onReset }) {
  return (
    <header className="border-b border-white/[0.06] sticky top-0 z-50 backdrop-blur-md bg-dark-900/80">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <button onClick={onReset} className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-pink-500 to-violet-500 flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 9l3-5 3.5 3L11 3l3 6" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><rect x="2" y="11" width="12" height="1.5" rx="0.75" fill="white"/></svg>
          </div>
          <span className="font-display font-bold text-white text-lg">Clip<span className="text-pink-400">Craft</span> <span className="text-white/30 font-normal text-sm">AI</span></span>
        </button>
        <a href="https://github.com" target="_blank" rel="noreferrer" className="btn-secondary text-xs py-2 px-4">GitHub ↗</a>
      </div>
    </header>
  );
}
