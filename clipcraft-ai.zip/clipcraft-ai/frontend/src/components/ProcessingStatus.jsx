const STEPS = {
  uploading:    { label: 'Uploading file…',           icon: '📤', sub: 'Sending to server' },
  transcribing: { label: 'Transcribing with Whisper…', icon: '🎧', sub: 'Converting speech to text with timestamps' },
  analyzing:    { label: 'AI Finding Best Moments…',   icon: '🧠', sub: 'GPT-4o analyzing for viral potential' },
};

export default function ProcessingStatus({ step, progress }) {
  const info = STEPS[step] || {};
  return (
    <div className="max-w-lg mx-auto text-center py-20 animate-fade-in">
      <div className="text-6xl mb-6">{info.icon}</div>
      <h2 className="font-display text-2xl font-bold text-white mb-2">{info.label}</h2>
      <p className="text-white/40 text-sm mb-10">{info.sub}</p>
      <div className="flex justify-center gap-1 mb-8" aria-label="processing indicator">
        {[1,2,3,4,5].map(i=><span key={i} className="wave-bar" style={{animationDelay:`${i*0.1}s`}} />)}
      </div>
      {step === 'uploading' && progress > 0 && (
        <div>
          <div className="h-1.5 bg-dark-700 rounded-full overflow-hidden max-w-xs mx-auto">
            <div className="h-full bg-gradient-to-r from-pink-500 to-violet-500 rounded-full transition-all duration-300" style={{width:`${progress}%`}} />
          </div>
          <p className="text-white/30 text-xs mt-2">{progress}%</p>
        </div>
      )}
      {step !== 'uploading' && (
        <div className="h-1.5 bg-dark-700 rounded-full overflow-hidden max-w-xs mx-auto">
          <div className="h-full bg-gradient-to-r from-pink-500 to-violet-500 rounded-full animate-pulse" style={{width:'70%'}} />
        </div>
      )}
    </div>
  );
}
