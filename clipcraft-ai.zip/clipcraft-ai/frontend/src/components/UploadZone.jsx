import { useState, useRef } from 'react';

export default function UploadZone({ onSubmit }) {
  const [mode, setMode] = useState('file');
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState(null);
  const [url, setUrl] = useState('');
  const ref = useRef();

  const canSubmit = mode === 'file' ? !!file : url.length > 8;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex gap-1 p-1 bg-dark-800 border border-white/[0.07] rounded-2xl mb-4">
        {[['file','🎙️  Audio File'],['url','🔗  Blog URL']].map(([m,label])=>(
          <button key={m} onClick={()=>setMode(m)} className={`flex-1 py-2.5 rounded-xl text-sm font-body font-medium transition-all ${mode===m?'bg-gradient-to-r from-pink-500 to-violet-500 text-white':'text-white/40 hover:text-white/70'}`}>{label}</button>
        ))}
      </div>

      {mode === 'file' ? (
        <div
          onDragOver={e=>{e.preventDefault();setDragging(true)}}
          onDragLeave={()=>setDragging(false)}
          onDrop={e=>{e.preventDefault();setDragging(false);const f=e.dataTransfer.files[0];if(f)setFile(f)}}
          onClick={()=>ref.current?.click()}
          className={`cursor-pointer rounded-2xl border-2 border-dashed p-14 text-center transition-all ${dragging?'border-pink-400 bg-pink-500/10':file?'border-green-500/50 bg-green-500/5':'border-white/10 bg-dark-800 hover:border-white/20'}`}
        >
          <input ref={ref} type="file" accept=".mp3,.wav,.m4a,.ogg,.flac,.mp4,.mov" className="hidden" onChange={e=>setFile(e.target.files[0])} />
          {file ? (
            <div>
              <div className="text-4xl mb-3">🎵</div>
              <p className="text-green-400 font-body font-medium">{file.name}</p>
              <p className="text-white/30 text-sm mt-1">{(file.size/1024/1024).toFixed(1)} MB</p>
            </div>
          ) : (
            <div>
              <div className="text-5xl mb-4">🎙️</div>
              <p className="text-white/70 font-body font-medium">Drop your podcast here</p>
              <p className="text-white/30 text-sm mt-2">MP3, WAV, M4A, MP4 · Max 100MB</p>
            </div>
          )}
        </div>
      ) : (
        <div className="card p-8">
          <label className="block text-white/50 text-sm font-body mb-2">Blog / Article URL</label>
          <input className="input-field" placeholder="https://yourblog.com/episode-123" value={url} onChange={e=>setUrl(e.target.value)} />
          <p className="text-white/25 text-xs mt-2">Paste any article or blog post — AI will extract the key moments.</p>
        </div>
      )}

      <button onClick={()=>canSubmit&&onSubmit(mode==='file'?{type:'file',file}:{type:'url',url})} disabled={!canSubmit} className="btn-primary w-full mt-4 py-4 text-base">
        ✨ Analyze with AI
      </button>
    </div>
  );
}
