import { useState, useRef } from 'react';
import { generateClip, getPreviewUrl, getDownloadUrl } from '../api.js';

export default function ClipCard({ clip, fileId, words }) {
  const [start, setStart]     = useState(clip.startTime.toFixed(1));
  const [end, setEnd]         = useState(clip.endTime.toFixed(1));
  const [logo, setLogo]       = useState(null);
  const [status, setStatus]   = useState('idle'); // idle | generating | done | error
  const [clipId, setClipId]   = useState(null);
  const [err, setErr]         = useState('');
  const logoRef               = useRef();

  const rankColors = ['from-pink-500 to-rose-500','from-violet-500 to-purple-500','from-blue-500 to-cyan-500'];

  const handleGenerate = async () => {
    setStatus('generating'); setErr('');
    try {
      const segWords = words.filter(w => w.start >= parseFloat(start) - 0.5 && w.end <= parseFloat(end) + 0.5);
      const result = await generateClip({
        fileId,
        startTime: parseFloat(start),
        endTime: parseFloat(end),
        words: segWords,
        captionText: clip.transcript,
        title: clip.title,
        logoFile: logo,
      });
      setClipId(result.clipId);
      setStatus('done');
    } catch (e) {
      setErr(e.message);
      setStatus('error');
    }
  };

  return (
    <div className="card flex flex-col overflow-hidden">
      {/* Header */}
      <div className={`bg-gradient-to-r ${rankColors[clip.rank-1]||rankColors[0]} p-4`}>
        <div className="flex items-center justify-between mb-1">
          <span className="text-white/70 text-xs font-mono font-medium">#{clip.rank} · {clip.clipType}</span>
          <span className="text-white text-xs font-body font-semibold bg-white/20 rounded-full px-2 py-0.5">{clip.engagementScore}/100</span>
        </div>
        <h3 className="font-display font-bold text-white text-lg leading-tight">{clip.title}</h3>
      </div>

      <div className="p-5 flex flex-col gap-4 flex-1">
        {/* Hook */}
        <div>
          <span className="text-white/30 text-xs font-body uppercase tracking-wider">Hook</span>
          <p className="text-white/80 text-sm mt-1 italic leading-relaxed">"{clip.hook}"</p>
        </div>

        {/* Reason */}
        <p className="text-white/40 text-xs leading-relaxed">{clip.engagementReason}</p>

        {/* Time editors */}
        <div className="grid grid-cols-2 gap-3">
          {[['Start (s)', start, setStart],['End (s)', end, setEnd]].map(([label, val, setter])=>(
            <div key={label}>
              <label className="text-white/30 text-xs block mb-1">{label}</label>
              <input type="number" step="0.1" min="0" value={val} onChange={e=>setter(e.target.value)}
                className="input-field py-2 text-xs" />
            </div>
          ))}
        </div>
        <p className="text-white/25 text-xs -mt-2">Duration: {(parseFloat(end)-parseFloat(start)).toFixed(1)}s</p>

        {/* Logo upload */}
        <div>
          <label className="text-white/30 text-xs block mb-1">Logo overlay (optional)</label>
          <div className="flex items-center gap-2">
            <button onClick={()=>logoRef.current?.click()} className="btn-secondary text-xs py-1.5 px-3">
              {logo ? '✅ ' + logo.name.substring(0,15) : '+ Upload Logo'}
            </button>
            {logo && <button onClick={()=>setLogo(null)} className="text-white/30 hover:text-white/60 text-xs">✕</button>}
          </div>
          <input ref={logoRef} type="file" accept="image/*" className="hidden" onChange={e=>setLogo(e.target.files[0])} />
        </div>

        {/* Suggested caption */}
        <div className="bg-dark-700 rounded-xl p-3">
          <span className="text-white/30 text-xs">Suggested Caption</span>
          <p className="text-white/60 text-xs mt-1 leading-relaxed">{clip.suggestedCaption}</p>
        </div>

        {/* Actions */}
        <div className="mt-auto pt-2 flex flex-col gap-2">
          {status !== 'done' && (
            <button onClick={handleGenerate} disabled={status==='generating'} className="btn-primary py-3 text-sm w-full">
              {status === 'generating' ? '⏳ Generating…' : '🎬 Generate Clip'}
            </button>
          )}
          {status === 'error' && <p className="text-red-400 text-xs text-center">{err}</p>}

          {status === 'done' && clipId && (
            <div className="flex flex-col gap-2">
              <video src={getPreviewUrl(clipId)} controls className="w-full rounded-xl bg-dark-700" style={{aspectRatio:'9/16',maxHeight:'280px',objectFit:'contain'}} />
              <a href={getDownloadUrl(clipId)} download className="btn-primary py-3 text-sm text-center w-full block">⬇️ Download MP4</a>
              <button onClick={()=>setStatus('idle')} className="btn-secondary text-xs py-2">Re-generate</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
